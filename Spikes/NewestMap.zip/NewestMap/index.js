import { AppRegistry } from 'react-native';
import App from './example/App';

AppRegistry.registerComponent('NewestMap', () => App);
